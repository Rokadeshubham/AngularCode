import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddcustComponent } from './addcust/addcust.component';

const routes: Routes = [
  {path:"AddCust",component:AddcustComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
