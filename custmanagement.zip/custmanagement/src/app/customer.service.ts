import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  url:string = "http://localhost:52974/api/Home";
  constructor(private _http:HttpClient) { }

  getInfo():Observable<any>
  {
   return this._http.get<any>(this.url);
  }
  Delete(id:number){
    let headers = new HttpHeaders()
    this._http.delete("http://localhost:52974/api/Home/"+id,{headers}).toPromise()
  }
  DetailInfo(id:number):Observable<any>{
    return this._http.get<any>("http://localhost:52974/api/Home/"+id);
  }

  //ADD Cust
  Add(customer:Customer):Observable<Customer>{
    let httpHeaders = new HttpHeaders()
    .set('Content-Type','application/json');
    let options = {
      headers :httpHeaders
    };
    return this._http.post<Customer>(this.url,customer,options);

  }
  //Update
  Update(customer:Customer){
    let httpHeaders = new HttpHeaders()
    .set('Content-Type','application/json');
    let options = {
      headers :httpHeaders
    };
   this._http.put<Customer>(this.url,customer,options).toPromise();

  }

}
