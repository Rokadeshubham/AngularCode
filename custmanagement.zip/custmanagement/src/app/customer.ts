export interface Customer {
    Departmentid:number,
    Name:String,
    City:string,
    Gender:String,
    Dob:Date

}
