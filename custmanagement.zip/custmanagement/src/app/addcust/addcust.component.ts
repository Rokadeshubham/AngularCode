import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Customer } from '../customer';

@Component({
  selector: 'app-addcust',
  templateUrl: './addcust.component.html',
  styleUrls: ['./addcust.component.css']
})
export class AddcustComponent {
  customers=[];
  addCustomer:FormGroup;
  constructor(private _service:CustomerService,private formbuilder:FormBuilder) { 
    this._service.getInfo().subscribe(s=>this.customers=s);
  }

  ngOnInit() {
    this.addCustomer = this.formbuilder.group({
      Departmentid:['',[Validators.required]],
      Name:['',[Validators.required]],
      City:['',[Validators.required]],
      Gender:['',[Validators.required]],
      Dob:['',[Validators.required]]
     
    })
  }
  datasaved:true;
  create(customer:Customer){
    this._service.Add(customer).subscribe(customer=>{this.datasaved=true})
  }

  onFormSubmit(){
    let customer = this.addCustomer.value;
    this.create(customer);
    this.addCustomer.reset();
  }
}
