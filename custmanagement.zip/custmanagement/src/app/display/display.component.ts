import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Customer } from '../customer';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent{
  customers=[];
  constructor(private _service:CustomerService,private formbuilder:FormBuilder) {
    this._service.getInfo().subscribe(s=>this.customers=s);
   }
  
  Delete(c){
    this._service.Delete(c);
  }

  newCust;
  Details(e){
    this._service.DetailInfo(e).subscribe(s=>this.newCust=s)
  }

//Update
updateCustomer:FormGroup;
Edit(e){
  this.updateCustomer.setValue(e);
}


ngOnInit() {
  this.updateCustomer = this.formbuilder.group({
    Departmentid:['',[Validators.required]],
    Name:['',[Validators.required]],
    City:['',[Validators.required]],
    Gender:['',[Validators.required]],
    Dob:['',[Validators.required]]
   
  })
}

updateinfo(customer:Customer){
  this._service.Update(customer);
}
onFormSubmit(){
  let customer = this.updateCustomer.value;
  this.updateinfo(customer);
  this.updateCustomer.reset();
}

}
